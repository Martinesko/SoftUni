﻿using System;

namespace CustomStack
{
    public class StartUp
    {
        static void Main()
        {
            Console.WriteLine("Hello World!");
        }
    }
}
