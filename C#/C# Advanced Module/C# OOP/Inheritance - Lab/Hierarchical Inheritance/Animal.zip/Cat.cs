﻿using System;

namespace Farm
{
    internal class Cat : Animal
    {
        public void Meow()
        {
            Console.WriteLine("meowing...");
        }
    }
}
